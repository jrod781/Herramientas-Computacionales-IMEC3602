# Familiarícese con las herramientas #

1. Cree una cuenta en Github.
2. Cree un repositorio llamado Herramientas Computacionales IMEC3602.
3. En el README del repositorio escriba sus objetivos principales para el curso.
